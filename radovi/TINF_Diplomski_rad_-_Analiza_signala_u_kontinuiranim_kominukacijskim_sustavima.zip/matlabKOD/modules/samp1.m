function varargout = samp1(varargin)
% SAMP1 M-file for samp1.fig
%      SAMP1, by itself, creates a new SAMP1 or raises the existing
%      singleton*.
%
%      H = SAMP1 returns the handle to a new SAMP1 or the handle to
%      the existing singleton*.
%
%      SAMP1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SAMP1.M with the given input arguments.
%
%      SAMP1('Property','Value',...) creates a new SAMP1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before samp1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to samp1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help samp1

% Last Modified by GUIDE v2.5 07-Sep-2009 20:14:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @samp1_OpeningFcn, ...
                   'gui_OutputFcn',  @samp1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before samp1 is made visible.
function samp1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to samp1 (see VARARGIN)

% Choose default command line output for samp1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes samp1 wait for user response (see UIRESUME)
% uiwait(handles.figure_samp1);


% --- Outputs from this function are returned to the command line.
function varargout = samp1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu_signal1.
function popupmenu_signal1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_signal1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_signal1

%dohvacanje zadane vrijednosti padajuceg menija
switch get(hObject,'Value')
    case 3
        %odabrani signal je pravokutni, ukljuci sve komponente parametara
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.slider_frekvencija1,'Enable','on');
        set(handles.text_faktor1,'Enable','on');
        set(handles.text_faktor1,'Visible','on');
        set(handles.edit_faktor1,'Enable','on');
        set(handles.edit_faktor1,'Visible','on');
        set(handles.popupmenu_signal1,'Position',[10 400 75 20]);
    case 6
        %odabrani signal je slijed pravokutnih impulsa, ukljuci sve
        %komponente parametara
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.slider_frekvencija1,'Enable','on');
        set(handles.text_faktor1,'Enable','on');
        set(handles.text_faktor1,'Visible','on');
        set(handles.edit_faktor1,'Enable','on');
        set(handles.edit_faktor1,'Visible','on');
        set(handles.popupmenu_signal1,'Position',[10 400 75 20]);
    case 8
        %odabrani signal je istosmjerni, ukljuci samo amplitudu
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','off');
        set(handles.edit_frekvencija1,'Enable','off');
        set(handles.slider_frekvencija1,'Enable','off');
        set(handles.text_faktor1,'Enable','off');
        set(handles.text_faktor1,'Visible','off');
        set(handles.edit_faktor1,'Enable','off');
        set(handles.edit_faktor1,'Visible','off');
        set(handles.popupmenu_signal1,'Position',[30 400 90 20]);
    otherwise
        %ostali signali, iskljuci samo faktor popunjenosti
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.slider_frekvencija1,'Enable','on');
        set(handles.text_faktor1,'Enable','off');
        set(handles.text_faktor1,'Visible','off');
        set(handles.edit_faktor1,'Enable','off');
        set(handles.edit_faktor1,'Visible','off');
        set(handles.popupmenu_signal1,'Position',[30 400 90 20]);
end


% --- Executes during object creation, after setting all properties.
function popupmenu_signal1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_amplituda1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_amplituda1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_amplituda1 as text
%        str2double(get(hObject,'String')) returns contents of edit_amplituda1 as a double

%dohvati string vrijednost parametra
A = get(hObject,'String');
A = regexprep(A,',','.'); %validacija - zamjeni decimalni zarez tockom

%konverzija stringa u numericku vrijednost
A = str2double(A);
A = round(A*2)/2; %zaokruzivanje amplitude na .5

%ako korisnik zada unos koji nije broj, default vrijednost je 1;
%ako je unos manji od 0.5, postavlja se na 0.5
if isnan(A)
    set(hObject,'String','1');
elseif (A < 0.5)
    set(hObject,'String','0.5');
else
    set(hObject,'String',num2str(A));
end


% --- Executes during object creation, after setting all properties.
function edit_amplituda1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_amplituda1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_frekvencija1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija1 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija1 as a double

%dohvati string vrijednost parametra
f = get(hObject,'String');
f = regexprep(f,',','.'); %validacija - zamjeni decimalni zarez tockom

%konverzija stringa u numericku vrijednost
f = round(str2double(f)); %frekvencija se zaokruzuje na cijeli broj

%ako korisnik zada unos koji nije broj, ili je unos manji od 1,
%default vrijednost je 1; najveca dopustena vrijendnost unosa je 10
if (isnan(f) || f < 1)
    set(hObject,'String','1');
    set(handles.slider_frekvencija1,'Value',1);
elseif (f > 10)
    set(hObject,'String','10');
    set(handles.slider_frekvencija1,'Value',10);
else
    set(hObject,'String',num2str(f));
    set(handles.slider_frekvencija1,'Value',f);
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_frekvencija1_Callback(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%pokupi vrijednost slidera
sliderValue = get(hObject,'Value');

%postavi vrijednost slidera u odgovarajucu edit komponentu
set(handles.edit_frekvencija1,'String', num2str(round(sliderValue)));


% --- Executes during object creation, after setting all properties.
function slider_frekvencija1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu_signal2.
function popupmenu_signal2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_signal2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_signal2

switch get(hObject,'Value')
    case 1
        set(handles.text_amplituda2,'Enable','off');
        set(handles.edit_amplituda2,'Enable','off');
        set(handles.text_frekvencija2,'Enable','off');
        set(handles.edit_frekvencija2,'Enable','off');
        set(handles.slider_frekvencija2,'Enable','off');
        set(handles.text_faktor2,'Enable','off');
        set(handles.text_faktor2,'Visible','off');
        set(handles.edit_faktor2,'Enable','off');
        set(handles.edit_faktor2,'Visible','off');
        set(handles.popupmenu_signal2,'Position',[30 270 90 20]);
    case 4
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','on');
        set(handles.slider_frekvencija2,'Enable','on');
        set(handles.text_faktor2,'Enable','on');
        set(handles.text_faktor2,'Visible','on');
        set(handles.edit_faktor2,'Enable','on');
        set(handles.edit_faktor2,'Visible','on');
        set(handles.popupmenu_signal2,'Position',[10 270 75 20]);
    case 7
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','on');
        set(handles.slider_frekvencija2,'Enable','on');
        set(handles.text_faktor2,'Enable','on');
        set(handles.text_faktor2,'Visible','on');
        set(handles.edit_faktor2,'Enable','on');
        set(handles.edit_faktor2,'Visible','on');
        set(handles.popupmenu_signal2,'Position',[10 270 75 20]);
    case 9
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','off');
        set(handles.edit_frekvencija2,'Enable','off');
        set(handles.slider_frekvencija2,'Enable','off');
        set(handles.text_faktor2,'Enable','off');
        set(handles.text_faktor2,'Visible','off');
        set(handles.edit_faktor2,'Enable','off');
        set(handles.edit_faktor2,'Visible','off');
        set(handles.popupmenu_signal2,'Position',[30 270 90 20]);
    otherwise
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','on');
        set(handles.slider_frekvencija2,'Enable','on');
        set(handles.text_faktor2,'Enable','off');
        set(handles.text_faktor2,'Visible','off');
        set(handles.edit_faktor2,'Enable','off');
        set(handles.edit_faktor2,'Visible','off');
        set(handles.popupmenu_signal2,'Position',[30 270 90 20]);
end


% --- Executes during object creation, after setting all properties.
function popupmenu_signal2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_amplituda2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_amplituda2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_amplituda2 as text
%        str2double(get(hObject,'String')) returns contents of edit_amplituda2 as a double

A = get(hObject,'String');
A = regexprep(A,',','.');

A = str2double(A);
A = round(A*2)/2;

if isnan(A)
    set(hObject,'String','1');
elseif (A < 0.5)
    set(hObject,'String','0.5');
else
    set(hObject,'String',num2str(A));
end


% --- Executes during object creation, after setting all properties.
function edit_amplituda2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_amplituda2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_frekvencija2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija2 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija2 as a double

f = get(hObject,'String');
f = regexprep(f,',','.');

f = round(str2double(f));

if (isnan(f) || f < 1)
    set(hObject,'String','1');
    set(handles.slider_frekvencija2,'Value',1);
elseif (f > 10)
    set(hObject,'String','10');
    set(handles.slider_frekvencija2,'Value',10);
else
    set(hObject,'String',num2str(f));
    set(handles.slider_frekvencija2,'Value',f);
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_frekvencija2_Callback(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

sliderValue = get(hObject,'Value');

set(handles.edit_frekvencija2,'String', num2str(round(sliderValue)));


% --- Executes during object creation, after setting all properties.
function slider_frekvencija2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton_prikazi.
function pushbutton_prikazi_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_prikazi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

error = 0; %error zastavica

%rekonstrukcija zapocela, iskljuci gumb prikazi
set(hObject,'Enable','off');

t = 0:0.005:1; %period
x = zeros(1,length(t)); %priprema vektora signala

%parametri
A1 = get(handles.edit_amplituda1,'String');
A1 = str2double(A1);

A2 = get(handles.edit_amplituda2,'String');
A2 = str2double(A2);

A3 = get(handles.edit_amplituda3,'String');
A3 = str2double(A3);

f1 = get(handles.edit_frekvencija1,'String');
f1 = str2double(f1);

f2 = get(handles.edit_frekvencija2,'String');
f2 = str2double(f2);

f3 = get(handles.edit_frekvencija3,'String');
f3 = str2double(f3);

%prva komponenta signala
switch get(handles.popupmenu_signal1,'Value')   
    case 1
        %sinusni
        x = x+A1*sin(2*pi*f1*t);
    case 2
        %kosinusni
        x = x+A1*cos(2*pi*f1*t);
    case 3
        %pravokutni
        fp1 = get(handles.edit_faktor1,'String');
        fp1 = str2double(fp1)*100;
        x = x+A1*square(2*pi*f1*t,fp1);
    case 4
        %trokutasti
        x = x+A1*sawtooth(2*pi*f1*t,0.5);
    case 5
        %pilasti
        x = x+A1*sawtooth(2*pi*f1*t);
    case 6
        %slijed pravokutnih impulsa
        fp1 = get(handles.edit_faktor1,'String');
        fp1 = str2double(fp1);
        x = x+A1*pulstran(t,0:1/f1:1,'rectpuls',fp1/f1);
    case 7
        %slijed trokutastih impulsa
        x = x+A1*pulstran(t,0:1/f1:1,'tripuls',1/(2*f1));
    case 8
        %istosmjerni
        x = x+A1;
    otherwise
end

%druga komponenta signala
switch get(handles.popupmenu_signal2,'Value')   
    case 2
        %sinusni
        x = x+A2*sin(2*pi*f2*t);
    case 3
        %kosinusni
        x = x+A2*cos(2*pi*f2*t);
    case 4
        %pravokutni
        fp2 = get(handles.edit_faktor2,'String');
        fp2 = str2double(fp2)*100;
        x = x+A2*square(2*pi*f2*t,fp2);
    case 5
        %trokutasti
        x = x+A2*sawtooth(2*pi*f2*t,0.5);
    case 6
        %pilasti
        x = x+A2*sawtooth(2*pi*f2*t);
    case 7
        %slijed pravokutnih impulsa
        fp2 = get(handles.edit_faktor2,'String');
        fp2 = str2double(fp2);
        x = x+A2*pulstran(t,0:1/f2:1,'rectpuls',fp2/f2);
    case 8
        %slijed trokutastih impulsa
        x = x+A2*pulstran(t,0:1/f2:1,'tripuls',1/(2*f2));
    case 9
        %istosmjerni
        x = x+A2;
    otherwise
end

%treca komponenta signala
switch get(handles.popupmenu_signal3,'Value')   
    case 2
        %sinusni
        x = x+A3*sin(2*pi*f3*t);
    case 3
        %kosinusni
        x = x+A3*cos(2*pi*f3*t);
    case 4
        %pravokutni
        fp3 = get(handles.edit_faktor3,'String');
        fp3 = str2double(fp3)*100;
        x = x+A3*square(2*pi*f3*t,fp3);
    case 5
        %trokutasti
        x = x+A3*sawtooth(2*pi*f3*t,0.5);
    case 6
        %pilasti
        x = x+A3*sawtooth(2*pi*f3*t);
    case 7
        %slijed pravokutnih impulsa
        fp3 = get(handles.edit_faktor3,'String');
        fp3 = str2double(fp3);
        x = x+A3*pulstran(t,0:1/f3:1,'rectpuls',fp3/f3);
    case 8
        %slijed trokutastih impulsa
        x = x+A3*pulstran(t,0:1/f3:1,'tripuls',1/(2*f3));
    case 9
        %istosmjerni
        x = x+A3;
    otherwise
end

%prikaz izvornog signala
plot(handles.axes1,t,x);
title(handles.axes1,'Izvorni signal');
xlabel(handles.axes1,'Vrijeme (sekunde)');
ylabel(handles.axes1,'Amplituda');
grid(handles.axes1);
[ymin,ymax] = yrange(x);
axis(handles.axes1,[min(t) max(t) ymin ymax]);

x_samples = x(1:10:201); %uzimamo 21 uzorak izvornog signala
%prikaz uzoraka
stem(handles.axes2,0:20,x_samples,'MarkerFaceColor',[0.25 0.75 0.25]);
title(handles.axes2,'Uzorkovani signal');
xlabel(handles.axes2,'Uzorci');
ylabel(handles.axes2,'Amplituda');
grid(handles.axes2);
axis(handles.axes2,[0 20 ymin ymax]);

x_recon = 0;
%rekonstrukcija korak po korak
for k = 0:length(x_samples)-1
    try
        %prikazi uzorke
        stem(handles.axes3,0:length(x_samples)-1,x_samples,'MarkerFaceColor',[0.25 0.75 0.25])
    catch
        %error handling
        %ako stem puca znaci da je gui zatvoren prije nego je
        %rekonstrukcija signala obavljena do kraja
        
        %postavi error zastavicu na 1 i izadji iz petlje
        error = 1;
        break;
    end
    if k == length(x_samples)-1
        title(handles.axes3,'Rekonstrukcija signala - zavr�ena!');
    else
        title(handles.axes3,'Rekonstrukcija signala - uzorak po uzorak');
    end
    xlabel(handles.axes3,'Uzorci');
    ylabel(handles.axes3,'Amplituda');
    grid(handles.axes3);
    l = k:-.1:-20+k;
    x_recon = x_recon+x_samples(k+1)*sinc(l);
    axis(handles.axes3,[0 20 ymin ymax]);
    hold(handles.axes3,'on');
    %prikazi rekonstrukciju trenutnog uzorka
    plot(handles.axes3,t*20,x_samples(k+1)*sinc(l),'r');
    %prikazi rekonstruirani signal
    plot(handles.axes3,t*20,x_recon);
    hold(handles.axes3,'off');
    if k < length(x_samples)-1
        %ukljuci gumb za sljedeci korak i zaustavi rekonstrukciju
        set(handles.pushbutton_korak,'Enable','on');
        uiwait;
    end
end

if (error == 0)
    %rekonstrukcija zavrsena, ukljuci gumb prikazi
    set(hObject,'Enable','on');
else
    %ne radi nista
    %try-catch blok je ulovio gresku i postavio error zastavicu na 1
end


% --- Executes on button press in pushbutton_korak.
function pushbutton_korak_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_korak (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%gumb za sljedeci korak je aktiviran, nastavi rekonstrukciju
uiresume;
set(hObject,'Enable','off');


function edit_amplituda3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_amplituda3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_amplituda3 as text
%        str2double(get(hObject,'String')) returns contents of edit_amplituda3 as a double

A = get(hObject,'String');
A = regexprep(A,',','.');

A = str2double(A);
A = round(A*2)/2;

if isnan(A)
    set(hObject,'String','1');
elseif (A < 0.5)
    set(hObject,'String','0.5');
else
    set(hObject,'String',num2str(A));
end


% --- Executes during object creation, after setting all properties.
function edit_amplituda3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_amplituda3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_frekvencija3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija3 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija3 as a double

f = get(hObject,'String');
f = regexprep(f,',','.');

f = round(str2double(f));

if (isnan(f) || f < 1)
    set(hObject,'String','1');
    set(handles.slider_frekvencija3,'Value',1);
elseif (f > 10)
    set(hObject,'String','10');
    set(handles.slider_frekvencija3,'Value',10);
else
    set(hObject,'String',num2str(f));
    set(handles.slider_frekvencija3,'Value',f);
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_frekvencija3_Callback(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

sliderValue = get(hObject,'Value');

set(handles.edit_frekvencija3,'String', num2str(round(sliderValue)));


% --- Executes during object creation, after setting all properties.
function slider_frekvencija3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu_signal3.
function popupmenu_signal3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_signal3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_signal3

switch get(hObject,'Value')
    case 1
        set(handles.text_amplituda3,'Enable','off');
        set(handles.edit_amplituda3,'Enable','off');
        set(handles.text_frekvencija3,'Enable','off');
        set(handles.edit_frekvencija3,'Enable','off');
        set(handles.slider_frekvencija3,'Enable','off');
        set(handles.text_faktor3,'Enable','off');
        set(handles.text_faktor3,'Visible','off');
        set(handles.edit_faktor3,'Enable','off');
        set(handles.edit_faktor3,'Visible','off');
        set(handles.popupmenu_signal3,'Position',[30 140 90 20]);
    case 4
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','on');
        set(handles.edit_frekvencija3,'Enable','on');
        set(handles.slider_frekvencija3,'Enable','on');
        set(handles.text_faktor3,'Enable','on');
        set(handles.text_faktor3,'Visible','on');
        set(handles.edit_faktor3,'Enable','on');
        set(handles.edit_faktor3,'Visible','on');
        set(handles.popupmenu_signal3,'Position',[10 140 75 20]);
    case 7
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','on');
        set(handles.edit_frekvencija3,'Enable','on');
        set(handles.slider_frekvencija3,'Enable','on');
        set(handles.text_faktor3,'Enable','on');
        set(handles.text_faktor3,'Visible','on');
        set(handles.edit_faktor3,'Enable','on');
        set(handles.edit_faktor3,'Visible','on');
        set(handles.popupmenu_signal3,'Position',[10 140 75 20]);
    case 9
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','off');
        set(handles.edit_frekvencija3,'Enable','off');
        set(handles.slider_frekvencija3,'Enable','off');
        set(handles.text_faktor3,'Enable','off');
        set(handles.text_faktor3,'Visible','off');
        set(handles.edit_faktor3,'Enable','off');
        set(handles.edit_faktor3,'Visible','off');
        set(handles.popupmenu_signal3,'Position',[30 140 90 20]);
    otherwise
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','on');
        set(handles.edit_frekvencija3,'Enable','on');
        set(handles.slider_frekvencija3,'Enable','on');
        set(handles.text_faktor3,'Enable','off');
        set(handles.text_faktor3,'Visible','off');
        set(handles.edit_faktor3,'Enable','off');
        set(handles.edit_faktor3,'Visible','off');
        set(handles.popupmenu_signal3,'Position',[30 140 90 20]);
end


% --- Executes during object creation, after setting all properties.
function popupmenu_signal3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_faktor1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_faktor1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_faktor1 as text
%        str2double(get(hObject,'String')) returns contents of edit_faktor1 as a double

fp = get(hObject,'String');
fp = regexprep(fp,',','.');

fp = str2double(fp);
fp = round(fp*20)/20; %faktor popunjenosti se zaokruzuje na .05

if isnan(fp)
    %default
    set(hObject,'String','0.5');
elseif (fp < 0.05)
    %najmanja dopustena vrijednost
    set(hObject,'String','0.05');
elseif (fp > 0.95)
    %najveca dopustena vrijednost
    set(hObject,'String','0.95');
else
    set(hObject,'String',num2str(fp));
end


% --- Executes during object creation, after setting all properties.
function edit_faktor1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_faktor1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_faktor2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_faktor2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_faktor2 as text
%        str2double(get(hObject,'String')) returns contents of edit_faktor2 as a double

fp = get(hObject,'String');
fp = regexprep(fp,',','.');

fp = str2double(fp);
fp = round(fp*20)/20;

if isnan(fp) 
    set(hObject,'String','0.5');
elseif (fp < 0.05)
    set(hObject,'String','0.05');
elseif (fp > 0.95)
    set(hObject,'String','0.95');
else
    set(hObject,'String',num2str(fp));
end


% --- Executes during object creation, after setting all properties.
function edit_faktor2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_faktor2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_faktor3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_faktor3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_faktor3 as text
%        str2double(get(hObject,'String')) returns contents of edit_faktor3 as a double

fp = get(hObject,'String');
fp = regexprep(fp,',','.');

fp = str2double(fp);
fp = round(fp*20)/20;

if isnan(fp) 
    set(hObject,'String','0.5');
elseif (fp < 0.05)
    set(hObject,'String','0.05');
elseif (fp > 0.95)
    set(hObject,'String','0.95');
else
    set(hObject,'String',num2str(fp));
end


% --- Executes during object creation, after setting all properties.
function edit_faktor3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_faktor3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

