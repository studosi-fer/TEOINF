function varargout = fir(varargin)
% FIR M-file for fir.fig
%      FIR, by itself, creates a new FIR or raises the existing
%      singleton*.
%
%      H = FIR returns the handle to a new FIR or the handle to
%      the existing singleton*.
%
%      FIR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FIR.M with the given input arguments.
%
%      FIR('Property','Value',...) creates a new FIR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fir_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fir_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help fir

% Last Modified by GUIDE v2.5 07-Sep-2009 20:17:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fir_OpeningFcn, ...
                   'gui_OutputFcn',  @fir_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fir is made visible.
function fir_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fir (see VARARGIN)

% Choose default command line output for fir
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes fir wait for user response (see UIRESUME)
% uiwait(handles.figure_fir);


% --- Outputs from this function are returned to the command line.
function varargout = fir_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function edit_red_Callback(hObject, eventdata, handles)
% hObject    handle to edit_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_red as text
%        str2double(get(hObject,'String')) returns contents of edit_red as a double

%dohvati string vrijednost parametra
n = get(hObject,'String');
n = regexprep(n,',','.'); %validacija - zamjeni decimalni zarez tockom

%konverzija stringa u numericku vrijednost
n = str2double(n);
n = round(n/2)*2; %zaokruzivanja reda filtra na paran broj

if isnan(n)
    %default
    set(hObject,'String','30');
elseif n < 2
    %najmanja dopustena vrijednost
    set(hObject,'String','2');
else
    set(hObject,'String',num2str(n));
end


% --- Executes during object creation, after setting all properties.
function edit_red_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_prikazi.
function pushbutton_prikazi_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_prikazi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%dohvati vrstu filtra
switch get(handles.popupmenu_filtar,'Value')   
    case 1
        %niskopropusni
        ftype = 'low';
        Wn = get(handles.edit_frekvencija2,'String');
        Wn = str2double(Wn);
    case 2
        %visokopropusni
        ftype = 'high';
        Wn = get(handles.edit_frekvencija1,'String');
        Wn = str2double(Wn);
    case 3
        %pojasnopropusni
        ftype = 'bandpass';
        Wn1 = get(handles.edit_frekvencija1,'String');
        Wn1 = str2double(Wn1);
        Wn2 = get(handles.edit_frekvencija2,'String');
        Wn2 = str2double(Wn2);
        Wn = [Wn1 Wn2];
    case 4
        %pojasna brana
        ftype = 'stop';
        Wn1 = get(handles.edit_frekvencija1,'String');
        Wn1 = str2double(Wn1);
        Wn2 = get(handles.edit_frekvencija2,'String');
        Wn2 = str2double(Wn2);
        Wn = [Wn1 Wn2];
    otherwise
end

%dohvati red filtra
n = get(handles.edit_red,'String');
n = str2double(n);

%dizajniraj filtar sa zadanim parametrima i racunaj njegov odziv
b = fir1(n,Wn,ftype);
[h,W] = freqz(b,1);

%prikazi impulsni odziv
stem(handles.axes1,0:length(b)-1,b,'MarkerFaceColor',[0.25 0.75 0.25]);
title(handles.axes1,'Impulsni odziv');
xlabel(handles.axes1,'Uzorci');
ylabel(handles.axes1,'Amplituda');
grid(handles.axes1);
[ymin,ymax] = yrange(b);
axis(handles.axes1,[-0.5,length(b)-0.5,ymin,ymax]);

%prikazi magnitudni odziv
plot(handles.axes2,W/pi,20*log10(abs(h)));
title(handles.axes2,'Magnitudni (dB) odziv');
xlabel(handles.axes2,'Normalizirana frekvencija (�\pi rad/uzorku)');
ylabel(handles.axes2,'Magnituda (dB)');
grid(handles.axes2);
[ymin,ymax] = yrange(20*log10(abs(h)));
axis(handles.axes2,[0,1-1/length(W),ymin,ymax]);

%prikazi fazni odziv
plot(handles.axes3,W/pi,180/pi*unwrap(angle(h)));
title(handles.axes3,'Fazni odziv');
xlabel(handles.axes3,'Normalizirana frekvencija (�\pi rad/uzorku)');
ylabel(handles.axes3,'Faza (stupnjevi)');
grid(handles.axes3);
[ymin,ymax] = yrange(180/pi*unwrap(angle(h)));
axis(handles.axes3,[0,1-1/length(W),ymin,ymax]);


function edit_frekvencija1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija1 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija1 as a double

%dohvati string vrijednost parametra
f = get(hObject,'String');
f = regexprep(f,',','.'); %validacija - zamjeni decimalni zarez tockom

%konverzija stringa u numericku vrijednost
f = str2double(f);
f = round(f*100)/100; %zaokruzivanje frekvencije na .01

%validacija - usporedjivanje granicnih frekvencija, fgg mora biti veca od
%fdg
if strcmp(get(handles.edit_frekvencija2,'Enable'),'on')
    if str2double(get(handles.edit_frekvencija2,'String')) <= f
        f = str2double(get(handles.edit_frekvencija2,'String'))-0.1;
    end
end

if isnan(f)
    %default
    set(hObject,'String','0.3');
elseif f < 0.01
    %najmanja dopustena vrijednost
    set(hObject,'String','0.01');
elseif f > 0.99
    %najveca dopustena vrijednost
    set(hObject,'String','0.99');
else
    set(hObject,'String',num2str(f));
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_frekvencija2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija2 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija2 as a double

f = get(hObject,'String');
f = regexprep(f,',','.');

f = str2double(f);
f = round(f*100)/100;

if strcmp(get(handles.edit_frekvencija1,'Enable'),'on')
    if str2double(get(handles.edit_frekvencija1,'String')) >= f
        f = str2double(get(handles.edit_frekvencija1,'String'))+0.1;
    end
end

if isnan(f)
    set(hObject,'String','0.7');
elseif f < 0.01
    set(hObject,'String','0.01');
elseif f > 0.99
    set(hObject,'String','0.99');
else
    set(hObject,'String',num2str(f));
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_filtar.
function popupmenu_filtar_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_filtar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_filtar contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_filtar

%dohvacanje vrste filtra i ukljucivanje odgovarajucih fg
switch get(hObject,'Value')
    case 1
        set(handles.edit_frekvencija1,'Enable','off');
        set(handles.edit_frekvencija2,'Enable','on');
    case 2
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','off');
    otherwise
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','on');
        Wn1 = get(handles.edit_frekvencija1,'String');
        Wn1 = str2double(Wn1);
        Wn2 = get(handles.edit_frekvencija2,'String');
        Wn2 = str2double(Wn2);
        if Wn1 > Wn2
            set(handles.edit_frekvencija1,'String',num2str(Wn2));
            set(handles.edit_frekvencija2,'String',num2str(Wn1));
        end
end


% --- Executes during object creation, after setting all properties.
function popupmenu_filtar_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_filtar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_prozor.
function popupmenu_prozor_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_prozor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_prozor contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_prozor


% --- Executes during object creation, after setting all properties.
function popupmenu_prozor_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_prozor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

