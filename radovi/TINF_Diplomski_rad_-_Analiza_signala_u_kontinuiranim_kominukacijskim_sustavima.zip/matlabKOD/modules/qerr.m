function varargout = qerr(varargin)
% QERR M-file for qerr.fig
%      QERR, by itself, creates a new QERR or raises the existing
%      singleton*.
%
%      H = QERR returns the handle to a new QERR or the handle to
%      the existing singleton*.
%
%      QERR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in QERR.M with the given input arguments.
%
%      QERR('Property','Value',...) creates a new QERR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before qerr_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to qerr_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help qerr

% Last Modified by GUIDE v2.5 07-Sep-2009 20:16:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @qerr_OpeningFcn, ...
                   'gui_OutputFcn',  @qerr_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before qerr is made visible.
function qerr_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to qerr (see VARARGIN)

% Choose default command line output for qerr
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes qerr wait for user response (see UIRESUME)
% uiwait(handles.figure_qerr);


% --- Outputs from this function are returned to the command line.
function varargout = qerr_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton_prikazi.
function pushbutton_prikazi_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_prikazi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

t = 0:0.001:1; %period

%dohvati vrstu signala
switch get(handles.popupmenu_signal,'Value')   
    case 1
        a = sin(2*pi*2*t);
    case 2
        a = cos(2*pi*2*t);
    case 3
        a = square(2*pi*2*t);
    case 4
        a = sawtooth(2*pi*2*t,0.5);
    case 5
        a = sawtooth(2*pi*2*t);
    case 6
        a = pulstran(t,0:1/2:1,'rectpuls',0.5/2);
    case 7
        a = pulstran(t,0:1/2:1,'tripuls',0.5/2);
    otherwise
end

%dohvati broj kvantizacijskih razina
switch get(handles.popupmenu_razina,'Value')
    case 1
        l = 8;
    case 2
        l = 16;
    otherwise
end;

%kvantizacija - koristi se funkcija iz knjige proakis-salehi
[sqnr,aquan,code] = u_pcm(a,l);

%prikaz izvornog i kvantiziranog signala
plot(handles.axes1,t,a,t,aquan);
title(handles.axes1,'Izvorni i kvantizirani signal');
xlabel(handles.axes1,'Vrijeme (sekunde)');
ylabel(handles.axes1,'Amplituda');
grid(handles.axes1);
[ymin,ymax] = yrange(a);
axis(handles.axes1,[min(t),max(t),ymin,ymax]);

%legenda
set(handles.pushbutton_legenda,'String','Poka�i legendu');
set(handles.pushbutton_legenda,'Visible','on');
set(handles.pushbutton_legenda,'Enable','on');

%prikaz kvantizacijske greske
plot(handles.axes2,0:length(t)-1,a-aquan);
title(handles.axes2,['Kvantizacijska pogre�ka - ' num2str(l) ' razina']);
xlabel(handles.axes2,'Uzorak');
ylabel(handles.axes2,'Pogre�ka');
grid(handles.axes2);
[ymin,ymax] = yrange(a-aquan);
axis(handles.axes2,[0,length(t)-1,ymin,ymax]);


% --- Executes on selection change in popupmenu_signal.
function popupmenu_signal_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_signal contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_signal


% --- Executes during object creation, after setting all properties.
function popupmenu_signal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_razina.
function popupmenu_razina_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_razina (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_razina contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_razina


% --- Executes during object creation, after setting all properties.
function popupmenu_razina_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_razina (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_legenda.
function pushbutton_legenda_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_legenda (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

switch get(hObject,'String')
    case 'Poka�i legendu'
        legend(handles.axes1,'Izvorni signal','Kvantizirani signal');
        set(handles.pushbutton_legenda,'String','Sakrij legendu');
    case 'Sakrij legendu'
        legend(handles.axes1,'hide');
        set(handles.pushbutton_legenda,'String','Poka�i legendu');
    otherwise
end

