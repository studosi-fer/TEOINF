function varargout = filt(varargin)
% FILT M-file for filt.fig
%      FILT, by itself, creates a new FILT or raises the existing
%      singleton*.
%
%      H = FILT returns the handle to a new FILT or the handle to
%      the existing singleton*.
%
%      FILT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FILT.M with the given input arguments.
%
%      FILT('Property','Value',...) creates a new FILT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before filt_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to filt_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help filt

% Last Modified by GUIDE v2.5 07-Sep-2009 20:12:01

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @filt_OpeningFcn, ...
                   'gui_OutputFcn',  @filt_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before filt is made visible.
function filt_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to filt (see VARARGIN)

% Choose default command line output for filt
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes filt wait for user response (see UIRESUME)
% uiwait(handles.figure_filt);


% --- Outputs from this function are returned to the command line.
function varargout = filt_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function edit_amplituda1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_amplituda1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_amplituda1 as text
%        str2double(get(hObject,'String')) returns contents of edit_amplituda1 as a double

A = get(hObject,'String');
A = regexprep(A,',','.');

A = str2double(A);
A = round(A*2)/2;

if isnan(A)
    set(hObject,'String','1');
elseif (A < 0.5)
    set(hObject,'String','0.5');
else
    set(hObject,'String',num2str(A));
end


% --- Executes during object creation, after setting all properties.
function edit_amplituda1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_amplituda1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_frekvencija1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija1 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija1 as a double

f = get(hObject,'String');
f = regexprep(f,',','.');

f = round(str2double(f));

if (isnan(f) || f < 1)
    set(hObject,'String','1');
    set(handles.slider_frekvencija1,'Value',1);
elseif (f > 10)
    set(hObject,'String','10');
    set(handles.slider_frekvencija1,'Value',10);
else
    set(hObject,'String',num2str(f));
    set(handles.slider_frekvencija1,'Value',f);
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_frekvencija1_Callback(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

sliderValue = get(hObject,'Value');

set(handles.edit_frekvencija1,'String', num2str(round(sliderValue)));


% --- Executes during object creation, after setting all properties.
function slider_frekvencija1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton_prikazi.
function pushbutton_prikazi_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_prikazi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

fs = 256;
Ts = 1/fs;
t = 0:Ts:1-Ts;
x = zeros(1,length(t));
z = zeros(1,length(t));

A1 = get(handles.edit_amplituda1,'String');
A1 = str2double(A1);

f1 = get(handles.edit_frekvencija1,'String');
f1 = str2double(f1);

A2 = get(handles.edit_amplituda2,'String');
A2 = str2double(A2);

f2 = get(handles.edit_frekvencija2,'String');
f2 = str2double(f2);

A3 = get(handles.edit_amplituda3,'String');
A3 = str2double(A3);

f3 = get(handles.edit_frekvencija3,'String');
f3 = str2double(f3);

%prva komponenta signala
switch get(handles.popupmenu_signal1,'Value')   
    case 1
        %sinusni
        x = x+A1*sin(2*pi*f1*t);
    case 2
        %kosinusni
        x = x+A1*cos(2*pi*f1*t);
    case 3
        %pravokutni
        fp1 = get(handles.edit_faktor1,'String');
        fp1 = str2double(fp1)*100;
        x = x+A1*square(2*pi*f1*t,fp1);
    case 4
        %trokutasti
        x = x+A1*sawtooth(2*pi*f1*t,0.5);
    case 5
        %pilasti
        x = x+A1*sawtooth(2*pi*f1*t);
    case 6
        %slijed pravokutnih impulsa
        fp1 = get(handles.edit_faktor1,'String');
        fp1 = str2double(fp1);
        x = x+A1*pulstran(t,0:1/f1:1,'rectpuls',fp1/f1);
    case 7
        %slijed trokutastih impulsa
        x = x+A1*pulstran(t,0:1/f1:1,'tripuls',1/(2*f1));
    case 8
        %istosmjerni
        x = x+A1;
    otherwise
end

%druga komponenta signala
switch get(handles.popupmenu_signal2,'Value')   
    case 2
        %sinusni
        x = x+A2*sin(2*pi*f2*t);
    case 3
        %kosinusni
        x = x+A2*cos(2*pi*f2*t);
    case 4
        %pravokutni
        fp2 = get(handles.edit_faktor2,'String');
        fp2 = str2double(fp2)*100;
        x = x+A2*square(2*pi*f2*t,fp2);
    case 5
        %trokutasti
        x = x+A2*sawtooth(2*pi*f2*t,0.5);
    case 6
        %pilasti
        x = x+A2*sawtooth(2*pi*f2*t);
    case 7
        %slijed pravokutnih impulsa
        fp2 = get(handles.edit_faktor2,'String');
        fp2 = str2double(fp2);
        x = x+A2*pulstran(t,0:1/f2:1,'rectpuls',fp2/f2);
    case 8
        %slijed trokutastih impulsa
        x = x+A2*pulstran(t,0:1/f2:1,'tripuls',1/(2*f2));
    case 9
        %istosmjerni
        x = x+A2;
    otherwise
end

%treca komponenta signala
switch get(handles.popupmenu_signal3,'Value')   
    case 2
        %sinusni
        x = x+A3*sin(2*pi*f3*t);
    case 3
        %kosinusni
        x = x+A3*cos(2*pi*f3*t);
    case 4
        %pravokutni
        fp3 = get(handles.edit_faktor3,'String');
        fp3 = str2double(fp3)*100;
        x = x+A3*square(2*pi*f3*t,fp3);
    case 5
        %trokutasti
        x = x+A3*sawtooth(2*pi*f3*t,0.5);
    case 6
        %pilasti
        x = x+A3*sawtooth(2*pi*f3*t);
    case 7
        %slijed pravokutnih impulsa
        fp3 = get(handles.edit_faktor3,'String');
        fp3 = str2double(fp3);
        x = x+A3*pulstran(t,0:1/f3:1,'rectpuls',fp3/f3);
    case 8
        %slijed trokutastih impulsa
        x = x+A3*pulstran(t,0:1/f3:1,'tripuls',1/(2*f3));
    case 9
        %istosmjerni
        x = x+A3;
    otherwise
end

%prikaz ulaznog signala u vremenskoj domeni
plot(handles.axes1,t,x);
title(handles.axes1,'Ulazni signal - Vremenska domena');
xlabel(handles.axes1,'Vrijeme (sekunde)');
ylabel(handles.axes1,'Amplituda');
grid(handles.axes1);
[ymin,ymax] = yrange(x);
axis(handles.axes1,[min(t) max(t) ymin ymax]);

%racunanje fft-a
[y,f] = fullfft(x);
m = abs(y);

%prikaz ulaznog signala u frekvencijskoj domeni
stem(handles.axes4,f,m,'MarkerFaceColor',[0.25 0.75 0.25]);
xlabel(handles.axes4,'Frekvencija (Hz)');
ylabel(handles.axes4,'Magnituda');
title(handles.axes4,'Ulazni signal - Frekvencijska domena');
grid(handles.axes4);
[ymin,ymax] = yrange(m);
axis(handles.axes4,[-25.5,25.5,ymin,ymax]);

set(handles.pushbutton_domena,'TooltipString','Prika�i frekvencijsku domenu');
set(handles.pushbutton_domena,'Visible','on');
set(handles.pushbutton_domena,'Enable','on');
set(handles.pushbutton_x,'String','Pove�aj x-os');
set(handles.pushbutton_x,'Visible','off');
set(handles.pushbutton_x,'Enable','off');
set(handles.axes4,'Visible','off');
axes(handles.axes1);

%generiranje idealnih filtara
switch get(handles.popupmenu_filtar,'Value')
    case 2
        %niskopropusni
        fg = get(handles.edit_gfrekvencija2,'String');
        fg = str2double(fg);
        
        for i = 1:length(f)
            if abs(f(i)) <= fg
                z(i) = 1;
            else
                z(i) = 0;
            end
        end
    case 3
        %visokopropusni
        fg = get(handles.edit_gfrekvencija1,'String');
        fg = str2double(fg);
        
        for i = 1:length(f)
            if abs(f(i)) >= fg
                z(i) = 1;
            else
                z(i) = 0;
            end
        end
    case 4
        %pojasnopropusni
        fg1 = get(handles.edit_gfrekvencija1,'String');
        fg1 = str2double(fg1);
        
        fg2 = get(handles.edit_gfrekvencija2,'String');
        fg2 = str2double(fg2);
        
        for i = 1:length(f)
            if (abs(f(i)) >= fg1)&&(abs(f(i)) <= fg2)
                z(i) = 1;
            else
                z(i) = 0;
            end
        end
    case 5
        %pojasna brana
        fg1 = get(handles.edit_gfrekvencija1,'String');
        fg1 = str2double(fg1);
        
        fg2 = get(handles.edit_gfrekvencija2,'String');
        fg2 = str2double(fg2);
        
        for i = 1:length(f)
            if (abs(f(i)) <= fg1)||(abs(f(i)) >= fg2)
                z(i) = 1;
            else
                z(i) = 0;
            end
        end
    otherwise
end

%prikaz filtra
plot(handles.axes2,f,z);
xlabel(handles.axes2,'Frekvencija (Hz)');
ylabel(handles.axes2,'Magnituda');
title(handles.axes2,'Filtar');
grid(handles.axes2);
[ymin,ymax] = yrange(z);
axis(handles.axes2,[-25.5,25.5,ymin,ymax]);

set(handles.axes5,'Visible','off');
axes(handles.axes2);

%racunanje vrmemenske domene izlaznog signala
yout = y.*z;
xout = ifft(ifftshift(yout))*fs;

%prikaz izlaznog signala u frekvencijkoj domeni
stem(handles.axes3,f,abs(yout),'MarkerFaceColor',[0.25 0.75 0.25]);
xlabel(handles.axes3,'Frekvencija (Hz)');
ylabel(handles.axes3,'Magnituda');
title(handles.axes3,'Izlazni signal - Frekvencijska domena');
grid(handles.axes3);
[ymin,ymax] = yrange(abs(yout));
axis(handles.axes3,[-25.5,25.5,ymin,ymax]);

%prikaz izlaznog signala u vremenskoj domeni
plot(handles.axes6,t,xout);
title(handles.axes6,'Izlazni signal - Vremenska domena');
xlabel(handles.axes6,'Vrijeme (sekunde)');
ylabel(handles.axes6,'Amplituda');
grid(handles.axes6);
[ymin,ymax] = yrange(xout);
axis(handles.axes6,[min(t) max(t) ymin ymax]);

set(handles.axes3,'Visible','off');
axes(handles.axes6);


function edit_amplituda2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_amplituda2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_amplituda2 as text
%        str2double(get(hObject,'String')) returns contents of edit_amplituda2 as a double

A = get(hObject,'String');
A = regexprep(A,',','.');

A = str2double(A);
A = round(A*2)/2;

if isnan(A)
    set(hObject,'String','1');
elseif (A < 0.5)
    set(hObject,'String','0.5');
else
    set(hObject,'String',num2str(A));
end


% --- Executes during object creation, after setting all properties.
function edit_amplituda2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_amplituda2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_frekvencija2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija2 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija2 as a double

f = get(hObject,'String');
f = regexprep(f,',','.');

f = round(str2double(f));

if (isnan(f) || f < 1)
    set(hObject,'String','1');
    set(handles.slider_frekvencija2,'Value',1);
elseif (f > 10)
    set(hObject,'String','10');
    set(handles.slider_frekvencija2,'Value',10);
else
    set(hObject,'String',num2str(f));
    set(handles.slider_frekvencija2,'Value',f);
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_frekvencija2_Callback(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

sliderValue = get(hObject,'Value');

set(handles.edit_frekvencija2,'String', num2str(round(sliderValue)));


% --- Executes during object creation, after setting all properties.
function slider_frekvencija2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu_signal1.
function popupmenu_signal1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_signal1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from
%        popupmenu_signal1

switch get(hObject,'Value')
    case 3
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.slider_frekvencija1,'Enable','on');
        set(handles.text_faktor1,'Enable','on');
        set(handles.text_faktor1,'Visible','on');
        set(handles.edit_faktor1,'Enable','on');
        set(handles.edit_faktor1,'Visible','on');
        set(handles.popupmenu_signal1,'Position',[10 490 75 20]);
    case 6
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.slider_frekvencija1,'Enable','on');
        set(handles.text_faktor1,'Enable','on');
        set(handles.text_faktor1,'Visible','on');
        set(handles.edit_faktor1,'Enable','on');
        set(handles.edit_faktor1,'Visible','on');
        set(handles.popupmenu_signal1,'Position',[10 490 75 20]);
    case 8
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','off');
        set(handles.edit_frekvencija1,'Enable','off');
        set(handles.slider_frekvencija1,'Enable','off');
        set(handles.text_faktor1,'Enable','off');
        set(handles.text_faktor1,'Visible','off');
        set(handles.edit_faktor1,'Enable','off');
        set(handles.edit_faktor1,'Visible','off');
        set(handles.popupmenu_signal1,'Position',[30 490 90 20]);
    otherwise
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.slider_frekvencija1,'Enable','on');
        set(handles.text_faktor1,'Enable','off');
        set(handles.text_faktor1,'Visible','off');
        set(handles.edit_faktor1,'Enable','off');
        set(handles.edit_faktor1,'Visible','off');
        set(handles.popupmenu_signal1,'Position',[30 490 90 20]);
end


% --- Executes during object creation, after setting all properties.
function popupmenu_signal1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_signal2.
function popupmenu_signal2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_signal2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_signal2

switch get(hObject,'Value')
    case 1
        set(handles.text_amplituda2,'Enable','off');
        set(handles.edit_amplituda2,'Enable','off');
        set(handles.text_frekvencija2,'Enable','off');
        set(handles.edit_frekvencija2,'Enable','off');
        set(handles.slider_frekvencija2,'Enable','off');
        set(handles.text_faktor2,'Enable','off');
        set(handles.text_faktor2,'Visible','off');
        set(handles.edit_faktor2,'Enable','off');
        set(handles.edit_faktor2,'Visible','off');
        set(handles.popupmenu_signal2,'Position',[30 360 90 20]);
    case 4
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','on');
        set(handles.slider_frekvencija2,'Enable','on');
        set(handles.text_faktor2,'Enable','on');
        set(handles.text_faktor2,'Visible','on');
        set(handles.edit_faktor2,'Enable','on');
        set(handles.edit_faktor2,'Visible','on');
        set(handles.popupmenu_signal2,'Position',[10 360 75 20]);
    case 7
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','on');
        set(handles.slider_frekvencija2,'Enable','on');
        set(handles.text_faktor2,'Enable','on');
        set(handles.text_faktor2,'Visible','on');
        set(handles.edit_faktor2,'Enable','on');
        set(handles.edit_faktor2,'Visible','on');
        set(handles.popupmenu_signal2,'Position',[10 360 75 20]);
    case 9
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','off');
        set(handles.edit_frekvencija2,'Enable','off');
        set(handles.slider_frekvencija2,'Enable','off');
        set(handles.text_faktor2,'Enable','off');
        set(handles.text_faktor2,'Visible','off');
        set(handles.edit_faktor2,'Enable','off');
        set(handles.edit_faktor2,'Visible','off');
        set(handles.popupmenu_signal2,'Position',[30 360 90 20]);
    otherwise
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','on');
        set(handles.slider_frekvencija2,'Enable','on');
        set(handles.text_faktor2,'Enable','off');
        set(handles.text_faktor2,'Visible','off');
        set(handles.edit_faktor2,'Enable','off');
        set(handles.edit_faktor2,'Visible','off');
        set(handles.popupmenu_signal2,'Position',[30 360 90 20]);
end


% --- Executes during object creation, after setting all properties.
function popupmenu_signal2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_filtar.
function popupmenu_filtar_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_filtar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_filtar contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_filtar

switch get(hObject,'Value')
    case 1
        set(handles.pushbutton_prikazi,'Enable','off');
        set(handles.text_gfrekvencija,'Enable','off');
        set(handles.edit_gfrekvencija1,'Enable','off');
        set(handles.edit_gfrekvencija2,'Enable','off');
    case 2
        set(handles.pushbutton_prikazi,'Enable','on');
        set(handles.text_gfrekvencija,'Enable','on');
        set(handles.edit_gfrekvencija1,'Enable','off');
        set(handles.edit_gfrekvencija2,'Enable','on');
    case 3
        set(handles.pushbutton_prikazi,'Enable','on');
        set(handles.text_gfrekvencija,'Enable','on');
        set(handles.edit_gfrekvencija1,'Enable','on');
        set(handles.edit_gfrekvencija2,'Enable','off');
    otherwise
        set(handles.pushbutton_prikazi,'Enable','on');
        set(handles.text_gfrekvencija,'Enable','on');
        set(handles.edit_gfrekvencija1,'Enable','on');
        set(handles.edit_gfrekvencija2,'Enable','on');
        fg1 = get(handles.edit_gfrekvencija1,'String');
        fg1 = str2double(fg1);
        fg2 = get(handles.edit_gfrekvencija2,'String');
        fg2 = str2double(fg2);
        if fg1 > fg2
            set(handles.edit_gfrekvencija1,'String',num2str(fg2));
            set(handles.edit_gfrekvencija2,'String',num2str(fg1));
        end
end


% --- Executes during object creation, after setting all properties.
function popupmenu_filtar_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_filtar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_gfrekvencija1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_gfrekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_gfrekvencija1 as text
%        str2double(get(hObject,'String')) returns contents of edit_gfrekvencija1 as a double

fg = get(hObject,'String');
fg = regexprep(fg,',','.');

fg = round(str2double(fg));

if strcmp(get(handles.edit_gfrekvencija2,'Enable'),'on')
    if str2double(get(handles.edit_gfrekvencija2,'String')) <= fg
        fg = str2double(get(handles.edit_gfrekvencija2,'String'))-1;
    end
end

if isnan(fg)
    if strcmp(get(handles.edit_gfrekvencija2,'Enable'),'on')
        s = str2double(get(handles.edit_gfrekvencija2,'String'))-1;
    end
    s = min([10 s]);
    set(hObject,'String',num2str(s));
    %set(hObject,'String','10');
elseif fg < 0
    set(hObject,'String','0');
% elseif fg > 0.99
%     set(hObject,'String','0.99');
else
    set(hObject,'String',num2str(fg));
end


% --- Executes during object creation, after setting all properties.
function edit_gfrekvencija1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_gfrekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_gfrekvencija2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_gfrekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_gfrekvencija2 as text
%        str2double(get(hObject,'String')) returns contents of edit_gfrekvencija2 as a double

fg = get(hObject,'String');
fg = regexprep(fg,',','.');

fg = round(str2double(fg));

if strcmp(get(handles.edit_gfrekvencija1,'Enable'),'on')
    if str2double(get(handles.edit_gfrekvencija1,'String')) >= fg
        fg = str2double(get(handles.edit_gfrekvencija1,'String'))+1;
    end
end

if isnan(fg)
    if strcmp(get(handles.edit_gfrekvencija1,'Enable'),'on')
        s = str2double(get(handles.edit_gfrekvencija1,'String'))+1;
    end
    s = max([10 s]);
    set(hObject,'String',num2str(s));
    %set(hObject,'String','10');
elseif fg < 0
    set(hObject,'String','0');
% elseif f > 0.99
%     set(hObject,'String','0.99');
else
    set(hObject,'String',num2str(fg));
end


% --- Executes during object creation, after setting all properties.
function edit_gfrekvencija2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_gfrekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_domena.
function pushbutton_domena_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_domena (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

switch get(handles.axes4,'Visible')
    case 'off'
        set(handles.axes1,'Visible','off');
        set(handles.axes4,'Visible','on');
        axes(handles.axes4);
        set(handles.axes6,'Visible','off');
        set(handles.axes3,'Visible','on');
        axes(handles.axes3);
        set(hObject,'TooltipString','Prika�i vremensku domenu');
        set(handles.pushbutton_x,'Visible','on');
        set(handles.pushbutton_x,'Enable','on');
    case 'on'
        set(handles.axes4,'Visible','off');
        set(handles.axes1,'Visible','on');
        axes(handles.axes1);
        set(handles.axes3,'Visible','off');
        set(handles.axes6,'Visible','on');
        axes(handles.axes6);
        set(hObject,'TooltipString','Prika�i frekvencijsku domenu');
        set(handles.pushbutton_x,'Visible','off');
        set(handles.pushbutton_x,'Enable','off');
    otherwise
end


% --- Executes on button press in pushbutton_x.
function pushbutton_x_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

switch get(hObject,'String')
    case 'Pove�aj x-os'
        xlim(handles.axes4,[-100.5,100.5]);
        xlim(handles.axes2,[-100.5,100.5]);
        xlim(handles.axes3,[-100.5,100.5]);
        set(hObject,'String','Smanji x-os');
    case 'Smanji x-os'
        xlim(handles.axes4,[-25.5,25.5]);
        xlim(handles.axes2,[-25.5,25.5]);
        xlim(handles.axes3,[-25.5,25.5]);
        set(hObject,'String','Pove�aj x-os');
    otherwise
end


function edit_amplituda3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_amplituda3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_amplituda3 as text
%        str2double(get(hObject,'String')) returns contents of edit_amplituda3 as a double

A = get(hObject,'String');
A = regexprep(A,',','.');

A = str2double(A);
A = round(A*2)/2;

if isnan(A)
    set(hObject,'String','1');
elseif (A < 0.5)
    set(hObject,'String','0.5');
else
    set(hObject,'String',num2str(A));
end


% --- Executes during object creation, after setting all properties.
function edit_amplituda3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_amplituda3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_frekvencija3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija3 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija3 as a double

f = get(hObject,'String');
f = regexprep(f,',','.');

f = round(str2double(f));

if (isnan(f) || f < 1)
    set(hObject,'String','1');
    set(handles.slider_frekvencija3,'Value',1);
elseif (f > 10)
    set(hObject,'String','10');
    set(handles.slider_frekvencija3,'Value',10);
else
    set(hObject,'String',num2str(f));
    set(handles.slider_frekvencija3,'Value',f);
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_frekvencija3_Callback(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

sliderValue = get(hObject,'Value');

set(handles.edit_frekvencija3,'String', num2str(round(sliderValue)));


% --- Executes during object creation, after setting all properties.
function slider_frekvencija3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu_signal3.
function popupmenu_signal3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_signal3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_signal3

switch get(hObject,'Value')
    case 1
        set(handles.text_amplituda3,'Enable','off');
        set(handles.edit_amplituda3,'Enable','off');
        set(handles.text_frekvencija3,'Enable','off');
        set(handles.edit_frekvencija3,'Enable','off');
        set(handles.slider_frekvencija3,'Enable','off');
        set(handles.text_faktor3,'Enable','off');
        set(handles.text_faktor3,'Visible','off');
        set(handles.edit_faktor3,'Enable','off');
        set(handles.edit_faktor3,'Visible','off');
        set(handles.popupmenu_signal3,'Position',[30 230 90 20]);
    case 4
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','on');
        set(handles.edit_frekvencija3,'Enable','on');
        set(handles.slider_frekvencija3,'Enable','on');
        set(handles.text_faktor3,'Enable','on');
        set(handles.text_faktor3,'Visible','on');
        set(handles.edit_faktor3,'Enable','on');
        set(handles.edit_faktor3,'Visible','on');
        set(handles.popupmenu_signal3,'Position',[10 230 75 20]);
    case 7
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','on');
        set(handles.edit_frekvencija3,'Enable','on');
        set(handles.slider_frekvencija3,'Enable','on');
        set(handles.text_faktor3,'Enable','on');
        set(handles.text_faktor3,'Visible','on');
        set(handles.edit_faktor3,'Enable','on');
        set(handles.edit_faktor3,'Visible','on');
        set(handles.popupmenu_signal3,'Position',[10 230 75 20]);
    case 9
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','off');
        set(handles.edit_frekvencija3,'Enable','off');
        set(handles.slider_frekvencija3,'Enable','off');
        set(handles.text_faktor3,'Enable','off');
        set(handles.text_faktor3,'Visible','off');
        set(handles.edit_faktor3,'Enable','off');
        set(handles.edit_faktor3,'Visible','off');
        set(handles.popupmenu_signal3,'Position',[30 230 90 20]);
    otherwise
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','on');
        set(handles.edit_frekvencija3,'Enable','on');
        set(handles.slider_frekvencija3,'Enable','on');
        set(handles.text_faktor3,'Enable','off');
        set(handles.text_faktor3,'Visible','off');
        set(handles.edit_faktor3,'Enable','off');
        set(handles.edit_faktor3,'Visible','off');
        set(handles.popupmenu_signal3,'Position',[30 230 90 20]);
end


% --- Executes during object creation, after setting all properties.
function popupmenu_signal3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_faktor1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_faktor1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_faktor1 as text
%        str2double(get(hObject,'String')) returns contents of edit_faktor1 as a double

fp = get(hObject,'String');
fp = regexprep(fp,',','.');

fp = str2double(fp);
fp = round(fp*20)/20;

if isnan(fp) 
    set(hObject,'String','0.5');
elseif (fp < 0.05)
    set(hObject,'String','0.05');
elseif (fp > 0.95)
    set(hObject,'String','0.95');
else
    set(hObject,'String',num2str(fp));
end


% --- Executes during object creation, after setting all properties.
function edit_faktor1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_faktor1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_faktor2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_faktor2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_faktor2 as text
%        str2double(get(hObject,'String')) returns contents of edit_faktor2 as a double

fp = get(hObject,'String');
fp = regexprep(fp,',','.');

fp = str2double(fp);
fp = round(fp*20)/20;

if isnan(fp) 
    set(hObject,'String','0.5');
elseif (fp < 0.05)
    set(hObject,'String','0.05');
elseif (fp > 0.95)
    set(hObject,'String','0.95');
else
    set(hObject,'String',num2str(fp));
end


% --- Executes during object creation, after setting all properties.
function edit_faktor2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_faktor2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_faktor3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_faktor3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_faktor3 as text
%        str2double(get(hObject,'String')) returns contents of edit_faktor3 as a double

fp = get(hObject,'String');
fp = regexprep(fp,',','.');

fp = str2double(fp);
fp = round(fp*20)/20;

if isnan(fp) 
    set(hObject,'String','0.5');
elseif (fp < 0.05)
    set(hObject,'String','0.05');
elseif (fp > 0.95)
    set(hObject,'String','0.95');
else
    set(hObject,'String',num2str(fp));
end


% --- Executes during object creation, after setting all properties.
function edit_faktor3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_faktor3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

