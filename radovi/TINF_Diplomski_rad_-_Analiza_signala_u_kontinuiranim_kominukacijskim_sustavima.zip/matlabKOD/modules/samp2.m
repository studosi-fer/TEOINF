function varargout = samp2(varargin)
% SAMP2 M-file for samp2.fig
%      SAMP2, by itself, creates a new SAMP2 or raises the existing
%      singleton*.
%
%      H = SAMP2 returns the handle to a new SAMP2 or the handle to
%      the existing singleton*.
%
%      SAMP2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SAMP2.M with the given input arguments.
%
%      SAMP2('Property','Value',...) creates a new SAMP2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before samp2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to samp2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help samp2

% Last Modified by GUIDE v2.5 07-Sep-2009 20:15:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @samp2_OpeningFcn, ...
                   'gui_OutputFcn',  @samp2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before samp2 is made visible.
function samp2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to samp2 (see VARARGIN)

% Choose default command line output for samp2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes samp2 wait for user response (see UIRESUME)
% uiwait(handles.figure_samp2);


% --- Outputs from this function are returned to the command line.
function varargout = samp2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function edit_frekvencija1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija1 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija1 as a double

%dohvati string vrijednost parametra
f = get(hObject,'String');
f = regexprep(f,',','.'); %validacija - zamjeni decimalni zarez tockom

%konverzija stringa u numericku vrijednost
f = round(str2double(f));

%ako korisnik zada unos koji nije broj, ili je unos manji od 1,
%default vrijednost je 1; najveca dopustena vrijendnost unosa je 10
if (isnan(f) || f < 1)
    set(hObject,'String','1');
    set(handles.slider_frekvencija1,'Value',1);
elseif (f > 10)
    set(hObject,'String','10');
    set(handles.slider_frekvencija1,'Value',10);
else
    set(hObject,'String',num2str(f));
    set(handles.slider_frekvencija1,'Value',f);
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_frekvencija1_Callback(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%pokupi vrijednost slidera
sliderValue = get(hObject,'Value');

%postavi vrijednost slidera u odgovarajucu edit komponentu
set(handles.edit_frekvencija1,'String', num2str(round(sliderValue)));


% --- Executes during object creation, after setting all properties.
function slider_frekvencija1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton_prikazi.
function pushbutton_prikazi_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_prikazi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%izvorni signal
fsBig = 256; %frekvencija uzorkovanja
TsSmall = 1/fsBig; %interval uzorkovanja 
tLong = 0:TsSmall:1-TsSmall; %period uzorkovanja
xLong = zeros(1,length(tLong)); %priprema vektora signala

%dohvati frekvenciju uzorkovanja
fs = get(handles.edit_uzorkovanje,'String');
fs = str2double(fs);

%uzorkovani signal
Ts = 1/fs; %interval uzorkovanja
t = 0:Ts:1-Ts; %period uzorkovanja
x = zeros(1,length(t)); %priprema vektora signala

%parametri
A1 = get(handles.edit_amplituda1,'String');
A1 = str2double(A1);

A2 = get(handles.edit_amplituda2,'String');
A2 = str2double(A2);

A3 = get(handles.edit_amplituda3,'String');
A3 = str2double(A3);

f1 = get(handles.edit_frekvencija1,'String');
f1 = str2double(f1);

f2 = get(handles.edit_frekvencija2,'String');
f2 = str2double(f2);

f3 = get(handles.edit_frekvencija3,'String');
f3 = str2double(f3);

switch get(handles.popupmenu_signal1,'Value')   
    case 1
        %sinusni
        x = x+A1*sin(2*pi*f1*t);
        xLong = xLong+A1*sin(2*pi*f1*tLong);
    case 2
        %kosinusni
        x = x+A1*cos(2*pi*f1*t);
        xLong = xLong+A1*cos(2*pi*f1*tLong);
    case 3
        %pravokutni
        fp1 = get(handles.edit_faktor1,'String');
        fp1 = str2double(fp1)*100;
        x = x+A1*square(2*pi*f1*t,fp1);
        xLong = xLong+A1*square(2*pi*f1*tLong,fp1);
    case 4
        %trokutasti
        x = x+A1*sawtooth(2*pi*f1*t,0.5);
        xLong = xLong+A1*sawtooth(2*pi*f1*tLong,0.5);
    case 5
        %pilasti
        x = x+A1*sawtooth(2*pi*f1*t);
        xLong = xLong+A1*sawtooth(2*pi*f1*tLong);
    case 6
        %slijed pravokutnih impulsa
        fp1 = get(handles.edit_faktor1,'String');
        fp1 = str2double(fp1);
        x = x+A1*pulstran(t,0:1/f1:1,'rectpuls',fp1/f1);
        xLong = xLong+A1*pulstran(tLong,0:1/f1:1,'rectpuls',fp1/f1);
    case 7
        %slijed trokutastih impulsa
        x = x+A1*pulstran(t,0:1/f1:1,'tripuls',1/(2*f1));
        xLong = xLong+A1*pulstran(tLong,0:1/f1:1,'tripuls',1/(2*f1));
    case 8
        %istosmjerni
        x = x+A1;
        xLong = xLong+A1;
    otherwise
end

switch get(handles.popupmenu_signal2,'Value')   
    case 2
        %sinusni
        x = x+A2*sin(2*pi*f2*t);
        xLong = xLong+A2*sin(2*pi*f2*tLong);
    case 3
        %kosinusni
        x = x+A2*cos(2*pi*f2*t);
        xLong = xLong+A2*cos(2*pi*f2*tLong);
    case 4
        %pravokutni
        fp2 = get(handles.edit_faktor2,'String');
        fp2 = str2double(fp2)*100;
        x = x+A2*square(2*pi*f2*t,fp2);
        xLong = xLong+A2*square(2*pi*f2*tLong,fp2);
    case 5
        %trokutasti
        x = x+A2*sawtooth(2*pi*f2*t,0.5);
        xLong = xLong+A2*sawtooth(2*pi*f2*tLong,0.5);
    case 6
        %pilasti
        x = x+A2*sawtooth(2*pi*f2*t);
        xLong = xLong+A2*sawtooth(2*pi*f2*tLong);
    case 7
        %slijed pravokutnih impulsa
        fp2 = get(handles.edit_faktor2,'String');
        fp2 = str2double(fp2);
        x = x+A2*pulstran(t,0:1/f2:1,'rectpuls',fp2/f2);
        xLong = xLong+A2*pulstran(tLong,0:1/f2:1,'rectpuls',fp2/f2);
    case 8
        %slijed trokutastih impulsa
        x = x+A2*pulstran(t,0:1/f2:1,'tripuls',1/(2*f2));
        xLong = xLong+A2*pulstran(tLong,0:1/f2:1,'tripuls',1/(2*f2));
    case 9
        %istosmjerni
        x = x+A2;
        xLong = xLong+A2;
    otherwise
end

switch get(handles.popupmenu_signal3,'Value')   
    case 2
        %sinusni
        x = x+A3*sin(2*pi*f3*t);
        xLong = xLong+A3*sin(2*pi*f3*tLong);
    case 3
        %kosinusni
        x = x+A3*cos(2*pi*f3*t);
        xLong = xLong+A3*cos(2*pi*f3*tLong);
    case 4
        %pravokutni
        fp3 = get(handles.edit_faktor3,'String');
        fp3 = str2double(fp3)*100;
        x = x+A3*square(2*pi*f3*t,fp3);
        xLong = xLong+A3*square(2*pi*f3*tLong,fp3);
    case 5
        %trokutasti
        x = x+A3*sawtooth(2*pi*f3*t,0.5);
        xLong = xLong+A3*sawtooth(2*pi*f3*tLong,0.5);
    case 6
        %pilasti
        x = x+A3*sawtooth(2*pi*f3*t);
        xLong = xLong+A3*sawtooth(2*pi*f3*tLong);
    case 7
        %slijed pravokutnih impulsa
        fp3 = get(handles.edit_faktor3,'String');
        fp3 = str2double(fp3);
        x = x+A3*pulstran(t,0:1/f3:1,'rectpuls',fp3/f3);
        xLong = xLong+A3*pulstran(tLong,0:1/f3:1,'rectpuls',fp3/f3);
    case 8
        %slijed trokutastih impulsa
        x = x+A3*pulstran(t,0:1/f3:1,'tripuls',1/(2*f3));
        xLong = xLong+A3*pulstran(tLong,0:1/f3:1,'tripuls',1/(2*f3));
    case 9
        %istosmjerni
        x = x+A3;
        xLong = xLong+A3;
    otherwise
end

%rekonstrukcija signala
xrec = 0;
for i = 1:fs
    xrec = xrec+x(i)*sinc(fs*(tLong-t(i)));
end

%prikaz izvornog signala
plot(handles.axes1,tLong,xLong);
xlabel(handles.axes1,'Vrijeme (sekunde)');
ylabel(handles.axes1,'Amplituda');
title(handles.axes1,'Izvorni i rekonstruirani signal')
grid(handles.axes1);
[ymin,ymax] = yrange(xLong);
axis(handles.axes1,[min(tLong),max(tLong),ymin,ymax]);
hold(handles.axes1,'on');
% plot(handles.axes1,t,y,'--rs','LineWidth',2,...
%                 'MarkerEdgeColor','k',...
%                 'MarkerFaceColor','g',...
%                 'MarkerSize',6);
%prikaz rekonstruiranog signala
plot(handles.axes1,tLong,xrec,'r');
%prikaz uzoraka
plot(handles.axes1,t,x,'s','MarkerEdgeColor','k',...
                           'MarkerFaceColor','g',...
                           'MarkerSize',6);
hold(handles.axes1,'off');

set(handles.pushbutton_legenda,'String','Poka�i legendu');
set(handles.pushbutton_legenda,'Visible','on');
set(handles.pushbutton_legenda,'Enable','on');

%racunanje fft-a izvornog signala
[y1,f1] = fullfft(xLong);
m1 = abs(y1);

%prikaz spektra izvornog signala
stem(handles.axes2,f1,m1,'MarkerFaceColor',[0.25 0.75 0.25]);
xlabel(handles.axes2,'Frekvencija (Hz)');
ylabel(handles.axes2,'Magnituda');
title(handles.axes2,'Izvorni signal - Frekvencijska domena');
grid(handles.axes2);
[ymin,ymax] = yrange(m1);
axis(handles.axes2,[-20.5,20.5,ymin,ymax]);

%racunanje fft-a rekonstruiranog signala
[y2,f2] = fullfft(x);
m2 = abs(y2);

%prikaz spektra rekonstruiranog signala
stem(handles.axes3,f2,m2,'MarkerFaceColor',[0.25 0.75 0.25]);
xlabel(handles.axes3,'Frekvencija (Hz)');
ylabel(handles.axes3,'Magnituda');
title(handles.axes3,'Rekonstruirani signal - Frekvencijska domena');
grid(handles.axes3);
axis(handles.axes3,[-20.5,20.5,ymin,max(m2)-ymin]);


% --- Executes on selection change in popupmenu_signal1.
function popupmenu_signal1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_signal1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_signal1

switch get(hObject,'Value')
    case 3
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.slider_frekvencija1,'Enable','on');
        set(handles.text_faktor1,'Enable','on');
        set(handles.text_faktor1,'Visible','on');
        set(handles.edit_faktor1,'Enable','on');
        set(handles.edit_faktor1,'Visible','on');
        set(handles.popupmenu_signal1,'Position',[10 400 75 20]);
    case 6
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.slider_frekvencija1,'Enable','on');
        set(handles.text_faktor1,'Enable','on');
        set(handles.text_faktor1,'Visible','on');
        set(handles.edit_faktor1,'Enable','on');
        set(handles.edit_faktor1,'Visible','on');
        set(handles.popupmenu_signal1,'Position',[10 400 75 20]);
    case 8
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','off');
        set(handles.edit_frekvencija1,'Enable','off');
        set(handles.slider_frekvencija1,'Enable','off');
        set(handles.text_faktor1,'Enable','off');
        set(handles.text_faktor1,'Visible','off');
        set(handles.edit_faktor1,'Enable','off');
        set(handles.edit_faktor1,'Visible','off');
        set(handles.popupmenu_signal1,'Position',[30 400 90 20]);
    otherwise
        set(handles.text_amplituda1,'Enable','on');
        set(handles.edit_amplituda1,'Enable','on');
        set(handles.text_frekvencija1,'Enable','on');
        set(handles.edit_frekvencija1,'Enable','on');
        set(handles.slider_frekvencija1,'Enable','on');
        set(handles.text_faktor1,'Enable','off');
        set(handles.text_faktor1,'Visible','off');
        set(handles.edit_faktor1,'Enable','off');
        set(handles.edit_faktor1,'Visible','off');
        set(handles.popupmenu_signal1,'Position',[30 400 90 20]);
end


% --- Executes during object creation, after setting all properties.
function popupmenu_signal1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_uzorkovanje_Callback(hObject, eventdata, handles)
% hObject    handle to edit_uzorkovanje (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_uzorkovanje as text
%        str2double(get(hObject,'String')) returns contents of edit_uzorkovanje as a double

f = get(hObject,'String');
f = regexprep(f,',','.');

f = round(str2double(f));

if (isnan(f) || f < 1)
    set(hObject,'String','1');
    set(handles.slider_uzorkovanje,'Value',1);
elseif (f > 41)
    set(hObject,'String','41');
    set(handles.slider_uzorkovanje,'Value',41);
else
    set(hObject,'String',num2str(f));
    set(handles.slider_uzorkovanje,'Value',f);
end


% --- Executes during object creation, after setting all properties.
function edit_uzorkovanje_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_uzorkovanje (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_uzorkovanje_Callback(hObject, eventdata, handles)
% hObject    handle to slider_uzorkovanje (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

sliderValue = get(hObject,'Value');

set(handles.edit_uzorkovanje,'String', num2str(round(sliderValue)));


% --- Executes during object creation, after setting all properties.
function slider_uzorkovanje_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_uzorkovanje (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


function edit_amplituda1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_amplituda1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_amplituda1 as text
%        str2double(get(hObject,'String')) returns contents of edit_amplituda1 as a double

%dohvati string vrijednost parametra
A = get(hObject,'String');
A = regexprep(A,',','.'); %validacija - zamjeni decimalni zarez tockom

%konverzija stringa u numericku vrijednost
A = str2double(A);
A = round(A*2)/2; %zaokruzivanje amplitude na .5

%ako korisnik zada unos koji nije broj, default vrijednost je 1;
%ako je unos manji od 0.5, postavlja se na 0.5
if isnan(A)
    set(hObject,'String','1');
elseif (A < 0.5)
    set(hObject,'String','0.5');
else
    set(hObject,'String',num2str(A));
end


% --- Executes during object creation, after setting all properties.
function edit_amplituda1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_amplituda1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_amplituda2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_amplituda2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_amplituda2 as text
%        str2double(get(hObject,'String')) returns contents of edit_amplituda2 as a double

A = get(hObject,'String');
A = regexprep(A,',','.');

A = str2double(A);
A = round(A*2)/2;

if isnan(A)
    set(hObject,'String','1');
elseif (A < 0.5)
    set(hObject,'String','0.5');
else
    set(hObject,'String',num2str(A));
end


% --- Executes during object creation, after setting all properties.
function edit_amplituda2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_amplituda2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_frekvencija2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija2 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija2 as a double

f = get(hObject,'String');
f = regexprep(f,',','.');

f = round(str2double(f));

if (isnan(f) || f < 1)
    set(hObject,'String','1');
    set(handles.slider_frekvencija2,'Value',1);
elseif (f > 10)
    set(hObject,'String','10');
    set(handles.slider_frekvencija2,'Value',10);
else
    set(hObject,'String',num2str(f));
    set(handles.slider_frekvencija2,'Value',f);
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_frekvencija2_Callback(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

sliderValue = get(hObject,'Value');

set(handles.edit_frekvencija2,'String', num2str(round(sliderValue)));


% --- Executes during object creation, after setting all properties.
function slider_frekvencija2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu_signal2.
function popupmenu_signal2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_signal2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_signal2

switch get(hObject,'Value')
    case 1
        set(handles.text_amplituda2,'Enable','off');
        set(handles.edit_amplituda2,'Enable','off');
        set(handles.text_frekvencija2,'Enable','off');
        set(handles.edit_frekvencija2,'Enable','off');
        set(handles.slider_frekvencija2,'Enable','off');
        set(handles.text_faktor2,'Enable','off');
        set(handles.text_faktor2,'Visible','off');
        set(handles.edit_faktor2,'Enable','off');
        set(handles.edit_faktor2,'Visible','off');
        set(handles.popupmenu_signal2,'Position',[30 270 90 20]);
    case 4
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','on');
        set(handles.slider_frekvencija2,'Enable','on');
        set(handles.text_faktor2,'Enable','on');
        set(handles.text_faktor2,'Visible','on');
        set(handles.edit_faktor2,'Enable','on');
        set(handles.edit_faktor2,'Visible','on');
        set(handles.popupmenu_signal2,'Position',[10 270 75 20]);
    case 7
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','on');
        set(handles.slider_frekvencija2,'Enable','on');
        set(handles.text_faktor2,'Enable','on');
        set(handles.text_faktor2,'Visible','on');
        set(handles.edit_faktor2,'Enable','on');
        set(handles.edit_faktor2,'Visible','on');
        set(handles.popupmenu_signal2,'Position',[10 270 75 20]);
    case 9
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','off');
        set(handles.edit_frekvencija2,'Enable','off');
        set(handles.slider_frekvencija2,'Enable','off');
        set(handles.text_faktor2,'Enable','off');
        set(handles.text_faktor2,'Visible','off');
        set(handles.edit_faktor2,'Enable','off');
        set(handles.edit_faktor2,'Visible','off');
        set(handles.popupmenu_signal2,'Position',[30 270 90 20]);
    otherwise
        set(handles.text_amplituda2,'Enable','on');
        set(handles.edit_amplituda2,'Enable','on');
        set(handles.text_frekvencija2,'Enable','on');
        set(handles.edit_frekvencija2,'Enable','on');
        set(handles.slider_frekvencija2,'Enable','on');
        set(handles.text_faktor2,'Enable','off');
        set(handles.text_faktor2,'Visible','off');
        set(handles.edit_faktor2,'Enable','off');
        set(handles.edit_faktor2,'Visible','off');
        set(handles.popupmenu_signal2,'Position',[30 270 90 20]);
end


% --- Executes during object creation, after setting all properties.
function popupmenu_signal2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_amplituda3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_amplituda3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_amplituda3 as text
%        str2double(get(hObject,'String')) returns contents of edit_amplituda3 as a double

A = get(hObject,'String');
A = regexprep(A,',','.');

A = str2double(A);
A = round(A*2)/2;

if isnan(A)
    set(hObject,'String','1');
elseif (A < 0.5)
    set(hObject,'String','0.5');
else
    set(hObject,'String',num2str(A));
end


% --- Executes during object creation, after setting all properties.
function edit_amplituda3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_amplituda3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_frekvencija3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frekvencija3 as text
%        str2double(get(hObject,'String')) returns contents of edit_frekvencija3 as a double

f = get(hObject,'String');
f = regexprep(f,',','.');

f = round(str2double(f));

if (isnan(f) || f < 1)
    set(hObject,'String','1');
    set(handles.slider_frekvencija3,'Value',1);
elseif (f > 10)
    set(hObject,'String','10');
    set(handles.slider_frekvencija3,'Value',10);
else
    set(hObject,'String',num2str(f));
    set(handles.slider_frekvencija3,'Value',f);
end


% --- Executes during object creation, after setting all properties.
function edit_frekvencija3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_frekvencija3_Callback(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

sliderValue = get(hObject,'Value');

set(handles.edit_frekvencija3,'String', num2str(round(sliderValue)));


% --- Executes during object creation, after setting all properties.
function slider_frekvencija3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_frekvencija3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu_signal3.
function popupmenu_signal3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu_signal3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_signal3

switch get(hObject,'Value')
    case 1
        set(handles.text_amplituda3,'Enable','off');
        set(handles.edit_amplituda3,'Enable','off');
        set(handles.text_frekvencija3,'Enable','off');
        set(handles.edit_frekvencija3,'Enable','off');
        set(handles.slider_frekvencija3,'Enable','off');
        set(handles.text_faktor3,'Enable','off');
        set(handles.text_faktor3,'Visible','off');
        set(handles.edit_faktor3,'Enable','off');
        set(handles.edit_faktor3,'Visible','off');
        set(handles.popupmenu_signal3,'Position',[30 140 90 20]);
    case 4
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','on');
        set(handles.edit_frekvencija3,'Enable','on');
        set(handles.slider_frekvencija3,'Enable','on');
        set(handles.text_faktor3,'Enable','on');
        set(handles.text_faktor3,'Visible','on');
        set(handles.edit_faktor3,'Enable','on');
        set(handles.edit_faktor3,'Visible','on');
        set(handles.popupmenu_signal3,'Position',[10 140 75 20]);
    case 7
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','on');
        set(handles.edit_frekvencija3,'Enable','on');
        set(handles.slider_frekvencija3,'Enable','on');
        set(handles.text_faktor3,'Enable','on');
        set(handles.text_faktor3,'Visible','on');
        set(handles.edit_faktor3,'Enable','on');
        set(handles.edit_faktor3,'Visible','on');
        set(handles.popupmenu_signal3,'Position',[10 140 75 20]);
    case 9
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','off');
        set(handles.edit_frekvencija3,'Enable','off');
        set(handles.slider_frekvencija3,'Enable','off');
        set(handles.text_faktor3,'Enable','off');
        set(handles.text_faktor3,'Visible','off');
        set(handles.edit_faktor3,'Enable','off');
        set(handles.edit_faktor3,'Visible','off');
        set(handles.popupmenu_signal3,'Position',[30 140 90 20]);
    otherwise
        set(handles.text_amplituda3,'Enable','on');
        set(handles.edit_amplituda3,'Enable','on');
        set(handles.text_frekvencija3,'Enable','on');
        set(handles.edit_frekvencija3,'Enable','on');
        set(handles.slider_frekvencija3,'Enable','on');
        set(handles.text_faktor3,'Enable','off');
        set(handles.text_faktor3,'Visible','off');
        set(handles.edit_faktor3,'Enable','off');
        set(handles.edit_faktor3,'Visible','off');
        set(handles.popupmenu_signal3,'Position',[30 140 90 20]);
end


% --- Executes during object creation, after setting all properties.
function popupmenu_signal3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_signal3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_legenda.
function pushbutton_legenda_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_legenda (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

switch get(hObject,'String')
    case 'Poka�i legendu'
        legend(handles.axes1,'Izvorni signal','Rekonstruirani signal','Uzorci');
        set(hObject,'String','Sakrij legendu');
    case 'Sakrij legendu'
        legend(handles.axes1,'hide');
        set(hObject,'String','Poka�i legendu');
    otherwise
end


function edit_faktor1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_faktor1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_faktor1 as text
%        str2double(get(hObject,'String')) returns contents of edit_faktor1 as a double

fp = get(hObject,'String');
fp = regexprep(fp,',','.');

fp = str2double(fp);
fp = round(fp*20)/20;

if isnan(fp) 
    set(hObject,'String','0.5');
elseif (fp < 0.05)
    set(hObject,'String','0.05');
elseif (fp > 0.95)
    set(hObject,'String','0.95');
else
    set(hObject,'String',num2str(fp));
end


% --- Executes during object creation, after setting all properties.
function edit_faktor1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_faktor1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_faktor2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_faktor2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_faktor2 as text
%        str2double(get(hObject,'String')) returns contents of edit_faktor2 as a double

fp = get(hObject,'String');
fp = regexprep(fp,',','.');

fp = str2double(fp);
fp = round(fp*20)/20;

if isnan(fp) 
    set(hObject,'String','0.5');
elseif (fp < 0.05)
    set(hObject,'String','0.05');
elseif (fp > 0.95)
    set(hObject,'String','0.95');
else
    set(hObject,'String',num2str(fp));
end


% --- Executes during object creation, after setting all properties.
function edit_faktor2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_faktor2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_faktor3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_faktor3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_faktor3 as text
%        str2double(get(hObject,'String')) returns contents of edit_faktor3 as a double

fp = get(hObject,'String');
fp = regexprep(fp,',','.');

fp = str2double(fp);
fp = round(fp*20)/20;

if isnan(fp) 
    set(hObject,'String','0.5');
elseif (fp < 0.05)
    set(hObject,'String','0.05');
elseif (fp > 0.95)
    set(hObject,'String','0.95');
else
    set(hObject,'String',num2str(fp));
end


% --- Executes during object creation, after setting all properties.
function edit_faktor3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_faktor3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

