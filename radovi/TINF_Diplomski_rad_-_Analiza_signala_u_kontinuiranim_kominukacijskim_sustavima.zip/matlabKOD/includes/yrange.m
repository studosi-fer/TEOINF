function [ymin,ymax] = yrange(yin)
%[ymin,ymax] = yrange(yin)
%
%funkcija za dimenzioniranje y-osi
%
%gornja granica postavlja se na 5% vecu vrijednost od raspona vrijednosti
%y-osi, donja granica na 5% manju

error(nargchk(1,1,nargin,'struct'));

if (min(yin) == max(yin))
    if (max(yin) > 0)
        ymin = max(yin)-0.55*max(yin);
        ymax = max(yin)+0.55*max(yin);
    elseif (max(yin) < 0)
        ymin = max(yin)-0.55*max(yin);
        ymax = max(yin)+0.55*max(yin);
    else
        ymin = -0.55;
        ymax = 0.55;
    end
else
    range = max(yin)-min(yin);
    
    ymin = min(yin)-0.05*range;
    ymax = max(yin)+0.05*range;
end

