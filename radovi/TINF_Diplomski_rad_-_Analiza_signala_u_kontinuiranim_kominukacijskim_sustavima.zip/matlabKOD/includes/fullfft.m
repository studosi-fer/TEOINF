function [y,f] = fullfft(x)
%[y,f] = fullfft(x)
%
%funkcija za pripremu grafickog prikaza dvostranog fft spektra

error(nargchk(1,1,nargin,'struct'));

%broj uzoraka ulaznog signala
n = length(x);

%generiranje frekvencijskog raspona
if (mod(n,2) == 0)
    f = -n/2:n/2-1;
else
    f = -(n-1)/2:(n-1)/2;
end

%fft ulaznog signala
%
%rezultat koji daje fft funkcija potrebno je podijeliti s brojem uzoraka i
%zatim primijeniti funkciju fftshift kako bi podaci bili centrirani oko
%nule
y = fft(x)/n;
y = fftshift(y);