function xout = toboolean(xin,threshold)
%xout = toboolean(xin,threshold)
%
%funkcija za stvaranje vektora boolean vrijednosti
%
%elementi ulaznog vektora cija je apsolutna vrijednost manja od praga
%odluke postavljaju se na 0, inace na 1
%
%xout = toboolean(xin)
%
%ukoliko se prag odluke ne zada kao argument funkcije, uzima se vrijednost
%0.001

error(nargchk(1,2,nargin,'struct'));

if nargin == 1
   threshold = 0.001;
end

xout = zeros(1,length(xin));

for i=1:length(xin)
    if abs(xin(i)) >= threshold
        xout(i) = 1;
    end
end